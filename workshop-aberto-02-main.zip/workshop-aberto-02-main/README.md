# workshop-aberto-02

[![Arquitetura](arquitetura_workshop.png)](https://link.excalidraw.com/l/8pvW6zbNUnD/5oOZyiYIuS1)